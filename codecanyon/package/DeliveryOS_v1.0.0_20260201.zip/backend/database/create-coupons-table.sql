-- Tabla de cupones/descuentos
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    description VARCHAR(255),
    discount_type ENUM('percentage', 'fixed') NOT NULL DEFAULT 'percentage',
    discount_value DECIMAL(10, 2) NOT NULL,
    min_order_amount DECIMAL(10, 2) DEFAULT 0.00,
    max_discount_amount DECIMAL(10, 2) NULL,
    usage_limit INT DEFAULT NULL,
    used_count INT DEFAULT 0,
    valid_from DATETIME DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_active (is_active),
    INDEX idx_valid_dates (valid_from, valid_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar cupones de ejemplo
INSERT INTO coupons (code, description, discount_type, discount_value, min_order_amount, max_discount_amount, usage_limit, valid_until) VALUES
('BIENVENIDO10', 'Descuento de bienvenida 10%', 'percentage', 10.00, 15.00, NULL, 100, DATE_ADD(NOW(), INTERVAL 30 DAY)),
('DESCUENTO5', 'Descuento fijo de $5', 'fixed', 5.00, 20.00, NULL, 50, DATE_ADD(NOW(), INTERVAL 60 DAY)),
('PRIMERACOMPRA', 'Primera compra 15% off', 'percentage', 15.00, 10.00, 20.00, NULL, DATE_ADD(NOW(), INTERVAL 90 DAY));
