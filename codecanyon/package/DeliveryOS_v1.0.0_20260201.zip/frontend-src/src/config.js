const API_URL = 'http://localhost/deliverySv/backend/api';

export default API_URL;
