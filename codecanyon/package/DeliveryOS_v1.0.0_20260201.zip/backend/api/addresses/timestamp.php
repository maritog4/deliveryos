<?php echo 'OK - ' . date('H:i:s'); ?>
